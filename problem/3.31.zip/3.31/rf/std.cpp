/*
  mail: mleautomaton@foxmail.com
  author: MLEAutoMaton
  This Code is made by MLEAutoMaton
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<queue>
#include<set>
#include<map>
#include<iostream>
using namespace std;
#define ll long long
#define re register
#define file(a) freopen(a".in","r",stdin);freopen(a".out","w",stdout)
#define int ll
inline int gi()
{
	int f=1,sum=0;char ch=getchar();
	while(ch>'9' || ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0' && ch<='9'){sum=(sum<<3)+(sum<<1)+ch-'0';ch=getchar();}
	return f*sum;
}
const int N=300010;
int front[N],cnt,Inf=1e18+10;
struct node
{
	int to,nxt,w,f;
}e[N<<1];
int s,t,dis[N],vis[N],fa[N],from[N],n,m,k;
void Add(int u,int v,int w,int f)
{
	e[cnt]=(node){v,front[u],w,f};front[u]=cnt++;
	e[cnt]=(node){u,front[v],0,-f};front[v]=cnt++;
}
queue<int>Q;
bool SPFA()
{
	for(int i=s;i<t+2;i++)dis[i]=1e18+10;
	Q.push(s);dis[s]=0;
	while(!Q.empty())
	{
		int u=Q.front();Q.pop();vis[u]=0;
		for(int i=front[u];i!=-1;i=e[i].nxt)
		{
			int v=e[i].to;
			if(dis[v]>dis[u]+e[i].f && e[i].w)
			{
				fa[v]=u;from[v]=i;dis[v]=dis[u]+e[i].f;
				if(!vis[v]){vis[v]=1;Q.push(v);}
			}
		}
	}
	return dis[t]!=dis[t+1];
}
pair<int,int>McMf()
{
	pair<int,int>ret;
	ret.first=ret.second=0;
	while(SPFA())
	{
		int di=Inf;
		for(int i=t;i!=s;i=fa[i])di=min(di,e[from[i]].w);
		ret.first+=di;ret.second+=di*dis[t];
		for(int i=t;i!=s;i=fa[i]){e[from[i]].w-=di;e[from[i]^1].w+=di;}
	}
	return ret;
}
signed main()
{
	while(scanf("%d",&n)==1)
	{
		memset(front,-1,sizeof(front));cnt=0;
		m=gi();/*s=gi();t=gi();*/k=gi();
		s=1;t=n;
		Add(0,s,k,0);Add(t,n+1,k,0);
		for(int i=1;i<=m;i++)
		{
			int u=gi(),v=gi(),a=gi(),w=gi();
			for(int j=1;j<=w;j++)Add(u,v,1,a*(j*j-(j-1)*(j-1)));
		}
		s=0;t=n+1;
		pair<int,int>ans=McMf();
		if(ans.first!=k){puts("-1");continue;}
		printf("%lld\n",ans.second);
	}
	return 0;
}
